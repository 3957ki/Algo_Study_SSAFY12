import org.apache.http.HttpResponse;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.util.EntityUtils;
import org.apache.poi.ss.usermodel.*;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.json.JSONArray;
import org.json.JSONObject;

import java.io.FileOutputStream;
import java.io.IOException;

public class ApiFetcher {
    public static void main(String[] args) throws Exception {
        // Create HttpClient
        CloseableHttpClient client = HttpClients.createDefault();

        // Create GET request
        HttpGet request = new HttpGet("https://solved.ac/api/v3/user/history?handle=phs7646&topic=rating");

        // Execute request
        HttpResponse response = client.execute(request);

        // Get response as a string
        String responseBody = EntityUtils.toString(response.getEntity());

        // Parse JSON response
        JSONArray jsonArray = new JSONArray(responseBody);

        // Create Workbook and Sheet
        Workbook workbook = new XSSFWorkbook();
        Sheet sheet = workbook.createSheet("History Data");

        // Create header row
        Row headerRow = sheet.createRow(0);
        Cell headerCell1 = headerRow.createCell(0);
        headerCell1.setCellValue("Timestamp");
        Cell headerCell2 = headerRow.createCell(1);
        headerCell2.setCellValue("Value");

        // Populate data rows
        int rowNum = 1;
        for (int i = 0; i < jsonArray.length(); i++) {
            JSONObject jsonObject = jsonArray.getJSONObject(i);
            Row row = sheet.createRow(rowNum++);
            row.createCell(0).setCellValue(jsonObject.getString("timestamp"));
            row.createCell(1).setCellValue(jsonObject.getInt("value"));
        }

        // Write the output to a file
        try (FileOutputStream fileOut = new FileOutputStream("UserHistoryData.xlsx")) {
            workbook.write(fileOut);
        }

        // Closing the workbook
        workbook.close();

        // Close the client
        client.close();
    }
}
