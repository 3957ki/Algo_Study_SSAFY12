import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.annotations.XYTextAnnotation;
import org.jfree.chart.axis.DateAxis;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.chart.plot.ValueMarker;
import org.jfree.chart.plot.XYPlot;
import org.jfree.chart.ui.RectangleAnchor;
import org.jfree.chart.ui.TextAnchor;
import org.jfree.data.time.RegularTimePeriod;
import org.jfree.data.time.Second;
import org.jfree.data.time.TimeSeries;
import org.jfree.data.time.TimeSeriesCollection;
import org.jfree.data.time.TimeSeriesDataItem;
import org.json.JSONArray;
import org.json.JSONObject;

import javax.swing.*;

import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Font;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.StringTokenizer;

import org.apache.http.HttpResponse;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.util.EntityUtils;

public class HistogramCrawler extends JFrame {
    List<String> handles;
    List<String> names;
    List<JSONArray> datas;

    HistogramCrawler() {
        handles = new ArrayList<>();
        names = new ArrayList<>();
        datas = new ArrayList<>();
        readParticipants();
        crawlData();
        createChart();
    }

    void readParticipants() {
        try (BufferedReader br = new BufferedReader(new FileReader("src/participants.txt"))) {
            String line;
            while ((line = br.readLine()) != null) {
            	if(line.charAt(0) == '#') continue;
                StringTokenizer st = new StringTokenizer(line.trim());
                handles.add(st.nextToken());
                names.add(st.nextToken());
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    void crawlData() {
        try {
            for (String handle : handles) {
                CloseableHttpClient client = HttpClients.createDefault();
                String req = "https://solved.ac/api/v3/user/history?handle=" + handle + "&topic=rating";
                HttpGet request = new HttpGet(req);
                HttpResponse response = client.execute(request);
                String responseBody = EntityUtils.toString(response.getEntity());
                datas.add(new JSONArray(responseBody));
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    void createChart() {
    	Color[] colors = { Color.RED, Color.BLUE, Color.GREEN, Color.ORANGE, new Color(0,33,137), 
                Color.MAGENTA, new Color(0,128,0), new Color(135,206,250), new Color(238,130,238), new Color(75, 137, 220) };
    	int[] padding = {1,1,5,1,1,3,4,1,1,1};
        TimeSeriesCollection dataset = new TimeSeriesCollection();
        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'");
        SimpleDateFormat checkFormat = new SimpleDateFormat("yyyy-MM-dd");
        Date referenceDate = null;
        try {
            referenceDate = checkFormat.parse("2024-07-15");
        } catch (ParseException e) {
            e.printStackTrace();
        }
        for (int i = 0; i < datas.size(); i++) {
            TimeSeries series = new TimeSeries(names.get(i));
            JSONArray jsonArray = datas.get(i);
            for (int j = 0; j < jsonArray.length(); j++) {
                JSONObject jsonObject = jsonArray.getJSONObject(j);
                String timestamp = jsonObject.getString("timestamp");
                double value = jsonObject.getDouble("value");
                try {
                    Date date = dateFormat.parse(timestamp);
                    if (!date.before(referenceDate))
                        series.addOrUpdate(new Second(date), value);
                } catch (ParseException e) {
                    e.printStackTrace();
                }
            }
            dataset.addSeries(series);
        }

        JFreeChart chart = ChartFactory.createTimeSeriesChart(
                "User Ratings Over Time",
                "Date",
                "Rating",
                dataset,
                true,
                true,
                false
        );

        XYPlot plot = (XYPlot) chart.getPlot();

        // 배경 색상 설정
        plot.setBackgroundPaint(Color.WHITE);

        // 선 두께 설정
        for (int i = 0; i < dataset.getSeriesCount(); i++) {
            plot.getRenderer().setSeriesStroke(i, new BasicStroke(2.0f)); // 모든 시리즈 두께 설정
            plot.getRenderer().setSeriesPaint(i, colors[i % colors.length]); // 미리 정의된 색상 할당
            // 라벨 추가
            TimeSeries series = dataset.getSeries(i);
            if (series.getItemCount() > 0) {
                // 마지막 데이터 포인트 가져오기
                TimeSeriesDataItem lastItem = series.getDataItem(series.getItemCount() - padding[i]);
                RegularTimePeriod period = lastItem.getPeriod();
                double yValue = lastItem.getValue().doubleValue();
                XYTextAnnotation annotation = new XYTextAnnotation(names.get(i), period.getMiddleMillisecond(), yValue);
                annotation.setFont(new Font("SansSerif", Font.BOLD, 12));
                annotation.setTextAnchor(TextAnchor.HALF_ASCENT_LEFT);
                annotation.setPaint(colors[i % colors.length]); // 동일한 색상으로 라벨 설정
                plot.addAnnotation(annotation);
            }
        }
        // y = 200에 가로선 추가
        ValueMarker marker3 = new ValueMarker(200);
        marker3.setPaint(Color.BLACK);
        marker3.setStroke(new BasicStroke(0.5f));
        marker3.setLabel("Silver");
        marker3.setLabelAnchor(RectangleAnchor.TOP_RIGHT);
        marker3.setLabelTextAnchor(TextAnchor.BOTTOM_RIGHT);
        plot.addRangeMarker(marker3);

        // y = 800에 가로선 추가
        ValueMarker marker = new ValueMarker(800);
        marker.setPaint(Color.BLACK);
        marker.setStroke(new BasicStroke(0.5f));
        marker.setLabel("Gold");
        marker.setLabelAnchor(RectangleAnchor.TOP_RIGHT);
        marker.setLabelTextAnchor(TextAnchor.BOTTOM_RIGHT);
        plot.addRangeMarker(marker);
        
        // y = 1600에 가로선 추가
        ValueMarker marker2 = new ValueMarker(1600);
        marker2.setPaint(Color.BLACK);
        marker2.setStroke(new BasicStroke(0.5f));
        marker2.setLabel("Platinum");
        marker2.setLabelAnchor(RectangleAnchor.TOP_RIGHT);
        marker2.setLabelTextAnchor(TextAnchor.BOTTOM_RIGHT);
        plot.addRangeMarker(marker2);

        DateAxis axis = (DateAxis) plot.getDomainAxis();
        axis.setDateFormatOverride(new SimpleDateFormat("MM-dd"));

        ChartPanel chartPanel = new ChartPanel(chart);
        chartPanel.setPreferredSize(new java.awt.Dimension(800, 600));
        setContentPane(chartPanel);
    }



    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            HistogramCrawler example = new HistogramCrawler();
            example.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
            example.pack();
            example.setVisible(true);
        });
    }
}
